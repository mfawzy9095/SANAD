package com.sanad.full;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.speech.*;
import android.webkit.*;
import android.widget.Toast;
import androidx.annotation.Nullable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO=40, REQ_EXPORT=41, REQ_IMPORT=42;
    private WebView web;
    private SpeechRecognizer recognizer;
    private String pendingLocale="ar-EG", pendingBackupJson=null;
    private boolean pageReady=false;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        web.addJavascriptInterface(new Bridge(),"Android");
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url){ pageReady=true; deliverQueuedBankMessages(); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ return true; }
        });
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        try { web.loadDataWithBaseURL("https://sanad.local/", readMasterHtml(), "text/html", "UTF-8", null); }
        catch(Exception e){ Toast.makeText(this,"SANAD source error: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private String readMasterHtml() throws IOException {
        String list=readAsset("parts.txt"); StringBuilder sb=new StringBuilder(260000);
        for(String n:list.split("\\n")){ n=n.trim(); if(!n.isEmpty()) sb.append(readAsset(n)); }
        return sb.toString();
    }
    private String readAsset(String name) throws IOException{
        try(InputStream in=getAssets().open(name); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1) out.write(buf,0,n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    public class Bridge {
        @JavascriptInterface public void startVoice(String locale){ runOnUiThread(()->startNativeVoice(locale)); }
        @JavascriptInterface public void stopVoice(){ runOnUiThread(()->{ if(recognizer!=null) try{recognizer.stopListening();}catch(Exception ignored){} }); }
        @JavascriptInterface public String getClipboard(){
            ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            if(cm==null||!cm.hasPrimaryClip()||cm.getPrimaryClip()==null||cm.getPrimaryClip().getItemCount()==0) return "";
            CharSequence t=cm.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this); return t==null?"":t.toString();
        }
        @JavascriptInterface public void saveBackup(String json){ runOnUiThread(()->beginExport(json)); }
        @JavascriptInterface public void pickBackup(){ runOnUiThread(MainActivity.this::beginImport); }
        @JavascriptInterface public void openNotificationAccess(){ runOnUiThread(()->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))); }
    }

    private void startNativeVoice(String locale){
        pendingLocale=(locale==null||locale.isBlank())?"ar-EG":locale;
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO); return; }
        try{
            if(recognizer!=null) recognizer.destroy();
            if(Build.VERSION.SDK_INT>=31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            else recognizer=SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener(){
                public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){}
                public void onError(int e){ js("window.sanadNativeVoiceError("+JSONObject.quote(voiceError(e))+")"); }
                public void onResults(Bundle b){ ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); String best=(r!=null&&!r.isEmpty())?r.get(0):""; js("window.sanadNativeVoiceResult("+JSONObject.quote(best)+")"); }
                public void onPartialResults(Bundle b){} public void onEvent(int e,Bundle b){}
            });
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,pendingLocale);
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5);
            recognizer.startListening(i);
        }catch(Exception e){ js("window.sanadNativeVoiceError("+JSONObject.quote("Offline voice unavailable: "+e.getClass().getSimpleName())+")"); }
    }
    private String voiceError(int e){
        if(e==SpeechRecognizer.ERROR_NO_MATCH) return "لم أفهم الجملة — جرّب مرة أخرى.";
        if(e==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) return "صلاحية الميكروفون مرفوضة.";
        if(Build.VERSION.SDK_INT>=31 && (e==SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED||e==SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) return "حزمة اللغة Offline غير متاحة على الجهاز.";
        if(e==SpeechRecognizer.ERROR_NETWORK||e==SpeechRecognizer.ERROR_NETWORK_TIMEOUT) return "التعرف المحلي غير متاح؛ SANAD لن يستخدم الإنترنت.";
        return "تعذر التعرف الصوتي المحلي ("+e+").";
    }

    private void beginExport(String json){
        pendingBackupJson=json;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/json"); i.putExtra(Intent.EXTRA_TITLE,"sanad-backup.json"); startActivityForResult(i,REQ_EXPORT);
    }
    private void beginImport(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/json"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,REQ_IMPORT); }
    @Override protected void onActivityResult(int req,int res,@Nullable Intent data){
        super.onActivityResult(req,res,data); if(res!=RESULT_OK||data==null||data.getData()==null)return; Uri u=data.getData();
        try{
            if(req==REQ_EXPORT && pendingBackupJson!=null){ try(OutputStream o=getContentResolver().openOutputStream(u)){ o.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8)); } pendingBackupJson=null; Toast.makeText(this,"تم حفظ نسخة SANAD",Toast.LENGTH_SHORT).show(); }
            else if(req==REQ_IMPORT){ String payload=readUri(u); js("window.sanadNativeRestore("+JSONObject.quote(payload)+")"); }
        }catch(Exception e){ Toast.makeText(this,"تعذر إكمال العملية",Toast.LENGTH_LONG).show(); }
    }
    private String readUri(Uri u)throws IOException{ try(InputStream in=getContentResolver().openInputStream(u); ByteArrayOutputStream o=new ByteArrayOutputStream()){ byte[] b=new byte[8192]; int n; while((n=in.read(b))!=-1){ if(o.size()>5_000_000) throw new IOException("Backup too large"); o.write(b,0,n);} return o.toString(StandardCharsets.UTF_8.name()); } }

    private void deliverQueuedBankMessages(){
        if(!pageReady)return; SharedPreferences p=getSharedPreferences("sanad_native",MODE_PRIVATE); String raw=p.getString("bank_queue","[]");
        try{ JSONArray a=new JSONArray(raw); p.edit().putString("bank_queue","[]").apply(); for(int i=0;i<a.length();i++) js("window.sanadNativeBankMessage("+JSONObject.quote(a.optString(i))+ ")"); }catch(Exception ignored){}
    }
    private void js(String code){ runOnUiThread(()->{ if(web!=null) web.evaluateJavascript(code,null); }); }
    @Override protected void onResume(){ super.onResume(); if(pageReady) deliverQueuedBankMessages(); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==REQ_AUDIO&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED) startNativeVoice(pendingLocale); else if(r==REQ_AUDIO) js("window.sanadNativeVoiceError('صلاحية الميكروفون مرفوضة.')"); }
    @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy(){ if(recognizer!=null) recognizer.destroy(); if(web!=null) web.destroy(); super.onDestroy(); }
}
