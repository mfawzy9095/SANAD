package com.sanad.full;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import org.json.JSONArray;
import java.util.Locale;

public class BankNotificationListener extends NotificationListenerService {
    private static final String[] SECURITY={"otp","one time password","verification code","security code","password","passcode","pin","cvv","رمز التحقق","رمز الأمان","كلمة المرور","الرقم السري","كود التحقق"};
    private static final String[] MONEY={"aed","درهم","sar","ريال","egp","جنيه","usd","دولار","eur","يورو"};
    private static final String[] SIGNAL={"purchase","purchased","transaction","card ending","used for","debited","debit","pos","تم استخدام","تم خصم","عملية شراء","عمليه شراء","بطاق"};
    @Override public void onNotificationPosted(StatusBarNotification sbn){
        Notification n=sbn.getNotification(); if(n==null)return; Bundle e=n.extras;
        String title=String.valueOf(e.getCharSequence(Notification.EXTRA_TITLE,""));
        String text=String.valueOf(e.getCharSequence(Notification.EXTRA_TEXT,""));
        CharSequence big=e.getCharSequence(Notification.EXTRA_BIG_TEXT,"");
        String raw=(title+" "+text+" "+(big==null?"":big)).trim(); String x=raw.toLowerCase(Locale.ROOT);
        if(raw.length()<8 || containsAny(x,SECURITY) || !containsAny(x,MONEY) || !containsAny(x,SIGNAL)) return;
        SharedPreferences p=getSharedPreferences("sanad_native",MODE_PRIVATE);
        try{ JSONArray a=new JSONArray(p.getString("bank_queue","[]")); if(a.length()>20){ JSONArray b=new JSONArray(); for(int i=Math.max(0,a.length()-10);i<a.length();i++)b.put(a.optString(i)); a=b; } a.put(raw); p.edit().putString("bank_queue",a.toString()).apply(); }catch(Exception ignored){}
    }
    private static boolean containsAny(String s,String[] terms){ for(String t:terms) if(s.contains(t)) return true; return false; }
}
