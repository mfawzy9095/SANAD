# SANAD - no shrinking rules needed for debug/master preview
