# SANAD — Full Master Android

هذا هو مشروع Android الرسمي المبني من `SANAD_MASTER_REVIEW` المسترجع، وليس الـMVP القديم.

## ما الذي يحتويه؟
- واجهة SANAD الكاملة: Home / Transactions / Budget / Insights / Settings / Financial Plan.
- عربي + English و RTL/LTR و Light/Dark.
- Text parser ورسائل البنك bulk والتعلم المحلي والحسابات والفئات والميزانيات.
- Goals + recurring bills + debts/installments + Safe-to-Spend.
- Multi-currency وJSON backup + restore.
- Native Android offline-first voice bridge.
- Native Notification Listener يرسل إشعارات الدفع للمراجعة داخل SANAD.
- لا يوجد `INTERNET` permission.

## البناء
GitHub Actions > **Build SANAD Full APK** > artifact: `SANAD-FULL-MASTER-APK`.

## ملاحظة
هذه نسخة Master Preview لاختبار كل الخصائص المسترجعة على Android قبل إعادة هندسة طبقة البيانات إلى Room/SQLite production architecture.
